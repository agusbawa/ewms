<?php

# Load the template library when the spark is loaded
$autoload['libraries'] = array('template');